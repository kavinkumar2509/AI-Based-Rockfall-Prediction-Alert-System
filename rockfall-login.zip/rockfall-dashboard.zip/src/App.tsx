import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import TacticalMapTab from './components/TacticalMapTab';
import SensorNetworkTab from './components/SensorNetworkTab';
import AiRiskAnalyticsTab from './components/AiRiskAnalyticsTab';
import AlertHistoryTab from './components/AlertHistoryTab';
import SystemConfigTab from './components/SystemConfigTab';
import { SafetyAlert, SensorData, HudMarker, AlertType, SectorName } from './types';
import { Map, Radio, Activity, AlertTriangle, Settings, ShieldAlert, X } from 'lucide-react';

type TabType = 'TACTICAL_MAP' | 'SENSOR_NETWORK' | 'AI_RISK' | 'ALERT_HISTORY' | 'SYSTEM_CONFIG';

const defaultAlerts: SafetyAlert[] = [
  {
    id: '1',
    timestamp: '14:02:44',
    type: 'ROUTINE',
    sector: 'ALPHA-1',
    message: 'System diagnostics complete. Standard telemetry within nominal baseline.',
    acknowledged: false,
  },
  {
    id: '2',
    timestamp: '07:34:11',
    type: 'WARNING',
    sector: 'DELTA-4',
    message: 'Precipitation accumulation in Sector Delta-4 causes 4% moisture coefficient increase.',
    acknowledged: false,
  }
];

const defaultSensors: SensorData[] = [
  { id: 'VIB-01', name: 'Seismic Vibration Array #1', value: 0.36, unit: 'g', status: 'ONLINE', threshold: 0.8, history: [0.34, 0.35, 0.36, 0.37, 0.35, 0.36, 0.38, 0.36] },
  { id: 'TILT-89', name: 'Shear Slope Inclinometer T-89', value: 6.86, unit: '°', status: 'ONLINE', threshold: 15.0, history: [6.80, 6.82, 6.85, 6.86, 6.84, 6.87, 6.89, 6.86] },
  { id: 'MOIST-04', name: 'Ground Moisture Probe M-04', value: 18.0, unit: '%', status: 'ONLINE', threshold: 40.0, history: [17, 18, 18, 19, 18, 17, 18, 18] },
  { id: 'RAIN-02', name: 'Pit Margin Pluviometer R-02', value: 0.0, unit: 'mm', status: 'STANDBY', threshold: 25.0, history: [0, 0, 0, 0, 0, 0, 0, 0] },
  { id: 'VIB-02', name: 'Seismic Vibration Array #2', value: 0.48, unit: 'g', status: 'ONLINE', threshold: 0.8, history: [0.44, 0.45, 0.48, 0.49, 0.47, 0.46, 0.48, 0.48] },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('TACTICAL_MAP');
  const [isSirenActive, setIsSirenActive] = useState<boolean>(false);
  const [simulationSpeed, setSimulationSpeed] = useState<'OFF' | '1X' | '5X' | '10X'>('1X');
  const [isAutoDiagnosticsEnabled, setIsAutoDiagnosticsEnabled] = useState<boolean>(true);
  
  // Audio chime indicator standard browser synthesized speech or buzzer fallback
  const [hasSoundBuzzed, setHasSoundBuzzed] = useState(false);

  // Geological thresholds state
  const [thresholds, setThresholds] = useState({
    vibration: 0.8,
    slopeTilt: 15.0,
    moisture: 40.0
  });

  const [sensors, setSensors] = useState<SensorData[]>(defaultSensors);
  const [alerts, setAlerts] = useState<SafetyAlert[]>(defaultAlerts);

  // Active/live sensor computed shortcuts
  const currentVib = sensors.find(s => s.id === 'VIB-01')?.value || 0.36;
  const currentTilt = sensors.find(s => s.id === 'TILT-89')?.value || 6.86;
  const currentMoist = sensors.find(s => s.id === 'MOIST-04')?.value || 18.0;
  const currentRain = sensors.find(s => s.id === 'RAIN-02')?.value || 0.0;

  // Unread Alerts Badge count
  const unreadAlertsCount = alerts.filter(a => !a.acknowledged).length;

  const handleTriggerSiren = () => {
    if (!isSirenActive) {
      // Sound active synthesized tone
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(880, audioCtx.currentTime + 0.8);
        gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 1.0);
        osc.start();
        osc.stop(audioCtx.currentTime + 1.2);
      } catch (err) {
        console.warn("AudioContext not allowed or not supported in this iframe layout context yet.", err);
      }

      setIsSirenActive(true);
      
      // Inject safety warning instantly
      const now = new Date();
      const timestamp = now.toTimeString().split(' ')[0];
      const emergencyWarning: SafetyAlert = {
        id: String(Date.now()),
        timestamp,
        type: 'EMERGENCY',
        sector: 'DELTA-4',
        message: 'EMERGENCY SHUTDOWN SIREN BROADCAST: Discontinuous slide displacement vector detected at shear bench Delta-4 rim! Evacuate Sector lower levels instantly.',
        acknowledged: false
      };
      setAlerts(prev => [emergencyWarning, ...prev]);
    } else {
      setIsSirenActive(false);
      // Inject routine clear log
      const now = new Date();
      const timestamp = now.toTimeString().split(' ')[0];
      const routineClear: SafetyAlert = {
        id: String(Date.now()),
        timestamp,
        type: 'ROUTINE',
        sector: 'ALPHA-1',
        message: 'Acoustic siren secured. Operations resuming normal structural benchmarking profiles.',
        acknowledged: false
      };
      setAlerts(prev => [routineClear, ...prev]);
    }
  };

  const handleAcknowledgeAlert = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
  };

  const handleClearAllAlerts = () => {
    setAlerts([]);
  };

  const handleAddCustomAlert = (type: AlertType, sector: SectorName, message: string) => {
    const now = new Date();
    const timestamp = now.toTimeString().split(' ')[0];
    const customAlert: SafetyAlert = {
      id: String(Date.now()),
      timestamp,
      type,
      sector,
      message,
      acknowledged: false
    };
    setAlerts(prev => [customAlert, ...prev]);
  };

  const handleToggleSensorStatus = (id: string) => {
    setSensors(prev => prev.map(s => {
      if (s.id === id) {
        const nextStatus = s.status === 'ONLINE' ? 'STANDBY' : 'ONLINE';
        return { ...s, status: nextStatus };
      }
      return s;
    }));
  };

  const handleUpdateThreshold = (key: string, value: number) => {
    setThresholds(prev => ({ ...prev, [key]: value }));
  };

  const handleCalibrateSensor = (id: string) => {
    // Zero out drift
    setSensors(prev => prev.map(s => {
      if (s.id === id) {
        return {
          ...s,
          value: s.id.startsWith('VIB') ? 0.36 : s.id.startsWith('TILT') ? 6.86 : 18.0,
          history: [...s.history.slice(1), s.id.startsWith('VIB') ? 0.36 : s.id.startsWith('TILT') ? 6.86 : 18.0]
        };
      }
      return s;
    }));
    
    // Broadcast notification check log
    const now = new Date();
    const timestamp = now.toTimeString().split(' ')[0];
    const maintAlert: SafetyAlert = {
      id: String(Date.now()),
      timestamp,
      type: 'MAINTENANCE',
      sector: 'ALPHA-1',
      message: `Calibration alignment check successfully completed for sensor module ${id}. Zero drift factors saved.`,
      acknowledged: false
    };
    setAlerts(prev => [maintAlert, ...prev]);
  };

  const handleResetAppData = () => {
    setIsSirenActive(false);
    setSensors(defaultSensors);
    setAlerts(defaultAlerts);
    setSimulationSpeed('1X');
    setIsAutoDiagnosticsEnabled(true);
    setThresholds({
      vibration: 0.8,
      slopeTilt: 15.0,
      moisture: 40.0
    });
  };

  // Live simulation background loop
  useEffect(() => {
    if (simulationSpeed === 'OFF') return;

    let multiplier = 1;
    if (simulationSpeed === '5X') multiplier = 5;
    if (simulationSpeed === '10X') multiplier = 10;

    const intervalVal = 3000 / multiplier;

    const interval = setInterval(() => {
      setSensors((prevSensors) =>
        prevSensors.map((sensor) => {
          if (sensor.status !== 'ONLINE') return sensor;

          let nextValue = sensor.value;
          if (isSirenActive) {
            // Settle or spike
            if (sensor.id.startsWith('VIB')) {
              nextValue = 1.34 + Math.random() * 0.15;
            } else if (sensor.id.startsWith('TILT')) {
              nextValue = 22.4 + Math.random() * 0.5;
            } else if (sensor.id.startsWith('MOIST')) {
              nextValue = 54 + Math.random() * 1.5;
            }
          } else {
            // Standard small wave fluctuations
            if (sensor.id.startsWith('VIB')) {
              // baseline 0.36
              const delta = (Math.random() - 0.5) * 0.05;
              nextValue = Math.max(0.1, Math.min(1.5, sensor.value + delta));
            } else if (sensor.id.startsWith('TILT')) {
              // baseline 6.86deg
              const delta = (Math.random() - 0.5) * 0.15;
              nextValue = Math.max(0, Math.min(45, sensor.value + delta));
            } else if (sensor.id.startsWith('MOIST')) {
              // baseline 18 %
              const delta = (Math.random() - 0.5) * 0.4;
              nextValue = Math.max(0, Math.min(100, sensor.value + delta));
            }
          }

          // Check if thresholds violated for auto diagnostics alerts
          if (isAutoDiagnosticsEnabled && nextValue > sensor.threshold && !isSirenActive) {
            // Check if alert already exists recently
            const duplicateCheck = alerts.some(a => a.message.includes(sensor.id) && !a.acknowledged);
            if (!duplicateCheck) {
              const now = new Date();
              const timestamp = now.toTimeString().split(' ')[0];
              const warningMessage: SafetyAlert = {
                id: String(Date.now() + Math.random()),
                timestamp,
                type: 'WARNING',
                sector: sensor.id === 'VIB-02' ? 'BETA-1' : 'DELTA-4',
                message: `ALERT THRESHOLD LATCHED: Sensor unit ${sensor.id} registers abnormal amplitude reading ${nextValue.toFixed(2)} [GATE VALUE: ${sensor.threshold}].`,
                acknowledged: false
              };
              setAlerts(prev => [warningMessage, ...prev]);
            }
          }

          return {
            ...sensor,
            value: nextValue,
            history: [...sensor.history.slice(1), nextValue],
          };
        })
      );
    }, intervalVal);

    return () => clearInterval(interval);
  }, [simulationSpeed, isSirenActive, isAutoDiagnosticsEnabled, alerts]);

  // Map types to simple hud structure for general analytics integration components
  const activeMarkers: HudMarker[] = [
    {
      id: '01',
      label: '01',
      name: 'Sector Alpha-1',
      top: '28%',
      left: '52%',
      telemetry: { vibration: currentVib, slopeTilt: currentTilt, moisture: currentMoist, rainfall: currentRain },
      stability: isSirenActive ? 'CRITICAL_MOVEMENT' : currentVib > thresholds.vibration ? 'CRITICAL_MOVEMENT' : currentTilt > thresholds.slopeTilt ? 'WARNING_DISPLACEMENT' : 'STABLE_SEISMIC',
      surveillance: isSirenActive ? 'CRITICAL' : currentVib > thresholds.vibration ? 'CRITICAL' : currentTilt > thresholds.slopeTilt ? 'WARNING' : 'NOMINAL',
      transmitters: ['Vibration Array #1', 'Inclinometer T-89']
    },
    {
      id: '02',
      label: '02',
      name: 'Sector Beta-1',
      top: '38%',
      left: '58%',
      telemetry: { vibration: 0.48, slopeTilt: 11.23, moisture: 24, rainfall: 2 },
      stability: 'WARNING_DISPLACEMENT',
      surveillance: 'WARNING',
      transmitters: ['Vibration Array #2', 'Telemetry Probe S-04']
    },
    {
      id: '03',
      label: '03',
      name: 'Sector Delta-4',
      top: '31%',
      left: '65%',
      telemetry: { vibration: 0.82, slopeTilt: 16.45, moisture: 38, rainfall: 12 },
      stability: 'CRITICAL_MOVEMENT',
      surveillance: 'CRITICAL',
      transmitters: ['Sensor T-89 Recalib', 'Pluviometer R-02']
    },
    {
      id: '04',
      label: '04',
      name: 'Sector Gamma-2',
      top: '41%',
      left: '52%',
      telemetry: { vibration: 0.21, slopeTilt: 3.42, moisture: 12, rainfall: 0 },
      stability: 'STABLE_SEISMIC',
      surveillance: 'NOMINAL',
      transmitters: ['Vibration Array #4', 'Inclinometer T-91']
    }
  ];

  return (
    <div className={`min-h-screen bg-[#131313] text-[#e4e2e1] antialiased pb-20 lg:pb-0 ${isSirenActive ? 'border-4 border-red-900 duration-300' : ''}`}>
      
      {/* Dynamic top bar alert message on high alert */}
      {isSirenActive && (
        <div className="bg-red-700 text-white font-mono text-[11px] font-bold text-center py-1.5 flex justify-center items-center gap-2 animate-pulse fixed w-full top-0 left-0 z-[100] px-4">
          <ShieldAlert className="w-4 h-4 animate-bounce" />
          <span>EMERGENCY OVERRIDE ALARM CONSOLE ACTIVATED. SIRENS BROADCASTING ACROSS COORD GRID ALPHA-1 / DELTA-4.</span>
          <button 
            onClick={() => setIsSirenActive(false)}
            className="ml-auto bg-red-900 border border-red-400 px-2.5 py-0.5 hover:bg-neutral-900 hover:text-red-400 cursor-pointer text-[10px]"
          >
            SILENCE
          </button>
        </div>
      )}

      {/* HEADER SECTION */}
      <Header
        threatLevel={isSirenActive ? 'CRITICAL' : currentVib > thresholds.vibration || currentTilt > thresholds.slopeTilt ? 'DELTA' : 'BETA'}
        isSirenActive={isSirenActive}
        onReset={handleResetAppData}
      />

      {/* APP WORKSPACE LAYOUT */}
      <div className="flex pt-20">
        
        {/* SIDEBAR NAVIGATION DRAWER */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          unreadAlertsCount={unreadAlertsCount}
          uptimePercent={isSirenActive ? 42 : 86}
        />

        {/* MAIN PANEL VIEW AREA */}
        <main className="flex-1 ml-0 lg:ml-72 p-4 lg:p-6 min-h-[calc(100vh-80px)] overflow-y-auto">
          {activeTab === 'TACTICAL_MAP' && (
            <TacticalMapTab
              sensors={{
                vibration: currentVib,
                slopeTilt: currentTilt,
                moisture: currentMoist,
                rainfall: currentRain,
              }}
              alerts={alerts}
              isSirenActive={isSirenActive}
              onTriggerSiren={handleTriggerSiren}
              onAcknowledgeAlert={handleAcknowledgeAlert}
            />
          )}

          {activeTab === 'SENSOR_NETWORK' && (
            <SensorNetworkTab
              sensors={sensors}
              onToggleStatus={handleToggleSensorStatus}
              onCalibrate={handleCalibrateSensor}
            />
          )}

          {activeTab === 'AI_RISK' && (
            <AiRiskAnalyticsTab
              markers={activeMarkers}
              isSirenActive={isSirenActive}
            />
          )}

          {activeTab === 'ALERT_HISTORY' && (
            <AlertHistoryTab
              alerts={alerts}
              onAcknowledgeAlert={handleAcknowledgeAlert}
              onClearAllAlerts={handleClearAllAlerts}
              onAddCustomAlert={handleAddCustomAlert}
            />
          )}

          {activeTab === 'SYSTEM_CONFIG' && (
            <SystemConfigTab
              thresholds={thresholds}
              simulationSpeed={simulationSpeed}
              isAutoDiagnosticsEnabled={isAutoDiagnosticsEnabled}
              onUpdateThreshold={handleUpdateThreshold}
              onUpdateSimSpeed={setSimulationSpeed}
              onToggleAutoDiag={() => setIsAutoDiagnosticsEnabled(!isAutoDiagnosticsEnabled)}
            />
          )}
        </main>
      </div>

      {/* BOTTOM NAV BAR (MOBILE MEDIA QUERY COMPLIANCE) */}
      <footer className="fixed bottom-0 left-0 right-0 z-50 bg-[#353535] border-t-2 border-[#4d4732] h-16 lg:hidden flex justify-around items-center select-none">
        
        <button
          onClick={() => setActiveTab('TACTICAL_MAP')}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            activeTab === 'TACTICAL_MAP' ? 'bg-[#ffd700] text-black font-bold' : 'text-[#d0c6ab] hover:bg-[#1f2020]'
          }`}
        >
          <Map className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-mono">Tactical</span>
        </button>

        <button
          onClick={() => setActiveTab('SENSOR_NETWORK')}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            activeTab === 'SENSOR_NETWORK' ? 'bg-[#ffd700] text-black font-bold' : 'text-[#d0c6ab] hover:bg-[#1f2020]'
          }`}
        >
          <Radio className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-mono">Sensors</span>
        </button>

        <button
          onClick={() => setActiveTab('AI_RISK')}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            activeTab === 'AI_RISK' ? 'bg-[#ffd700] text-black font-bold' : 'text-[#d0c6ab] hover:bg-[#1f2020]'
          }`}
        >
          <Activity className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-mono">AI Risk</span>
        </button>

        <button
          onClick={() => setActiveTab('ALERT_HISTORY')}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            activeTab === 'ALERT_HISTORY' ? 'bg-[#ffd700] text-black font-bold' : 'text-[#d0c6ab] hover:bg-[#1f2020]'
          }`}
        >
          <div className="relative">
            <AlertTriangle className="w-5 h-5 mb-1" />
            {unreadAlertsCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-red-600 border border-white text-white text-[9px] font-bold px-1 rounded-full animate-bounce">
                {unreadAlertsCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-mono">Alerts</span>
        </button>

        <button
          onClick={() => setActiveTab('SYSTEM_CONFIG')}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            activeTab === 'SYSTEM_CONFIG' ? 'bg-[#ffd700] text-black font-bold' : 'text-[#d0c6ab] hover:bg-[#1f2020]'
          }`}
        >
          <Settings className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-mono">Config</span>
        </button>
      </footer>

    </div>
  );
}
